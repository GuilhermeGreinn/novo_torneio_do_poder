package br.com.unicuritiba.TorneioDoPoder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TorneioDoPoderApplication {

	public static void main(String[] args) {
		SpringApplication.run(TorneioDoPoderApplication.class, args);
	}

}

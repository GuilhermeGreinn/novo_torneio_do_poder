package br.com.unicuritiba.TorneioDoPoder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TorneioDoPoderApplicationTests {

	@Test
	void contextLoads() {
	}

}
